﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Grade_Calculation
{
    class Program
    {
        static void Main(string[] args)
        {
            int rj, marks1, marks2, marks3, marks4, marks5, total;
            double per;
            string rk, div;

           

           

            Console.WriteLine("Enter the Obtained marks in Marks1:");
            marks1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Obtained marks in Marks2:");
            marks2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Obtained marks in Marks3");
            marks3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Obtained marks in Marks4:");
            marks4 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Obtained marks in Marks5:");
            marks5 = Convert.ToInt32(Console.ReadLine());

            // tm=total marks
            // pr= percentage(%)
            int tm = marks1 + marks2 + marks3 + marks4 + marks5;
            int pr = tm * 100 / 500;

            Console.WriteLine("Total Marks =" + tm);
            Console.WriteLine("Percentage(%) =" + pr + "%\n");

            if (pr > 60)
            {
                if (pr < 70)
                    Console.WriteLine("Grade-C");

                if (pr > 70)
                {
                    if (pr < 80)
                        Console.WriteLine("Grade-B");

                    if (pr > 80)
                        Console.WriteLine("Grade-A");
                    else
                        Console.WriteLine("Fail");

                }
                Console.ReadLine();
            }

            

        }
    }
}
